library(testthat)
library(qbrms)

test_check("qbrms")
